// Assuming the retrieved data is an array of objects with location and brand properties
const medicineSalesData = [
    { location: 'New York', brand: 'Brand A' },
    { location: 'New York', brand: 'Brand B' },
    { location: 'Los Angeles', brand: 'Brand C' },
    { location: 'Los Angeles', brand: 'Brand A' },
    // ...
  ];
  
  // Calculate the count of each brand in each location
  const brandCountsByLocation = medicineSalesData.reduce((counts, sale) => {
    const { location, brand } = sale;
    counts[location] = counts[location] || {};
    counts[location][brand] = (counts[location][brand] || 0) + 1;
    return counts;
  }, {});
  
  // Find the most popular brand in each location
  const mostPopularBrandsByLocation = Object.entries(brandCountsByLocation).reduce((popularBrands, [location, brandCounts]) => {
    const maxCount = Math.max(...Object.values(brandCounts));
    const mostPopularBrand = Object.keys(brandCounts).find(brand => brandCounts[brand] === maxCount);
    popularBrands[location] = mostPopularBrand;
    return popularBrands;
  }, {});
  
  console.log(mostPopularBrandsByLocation);
  