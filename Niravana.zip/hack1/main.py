# This Python code is for a web application system that generates a list of different locations along with the most sold medicine brands.

class Location:
    def __init__(self, name, medicines):
        """
        Initialize a Location object with a name and a list of medicines sold.
        
        Args:
        name (str): The name of the location.
        medicines (list): A list of medicine brands sold at the location.
        """
        self.name = name
        self.medicines = medicines

class WebApplication:
    def __init__(self):
        """
        Initialize a WebApplication object with an empty list of locations.
        """
        self.locations = []

    def add_location(self, location):
        """
        Add a Location object to the list of locations.
        
        Args:
        location (Location): The Location object to be added.
        """
        self.locations.append(location)

    def generate_location_medicine_list(self):
        """
        Generate a list of locations along with the most sold medicine brands.
        
        Returns:
        dict: A dictionary where the keys are location names and the values are the most sold medicine brands at each location.
        """
        location_medicine_list = {}
        for location in self.locations:
            location_medicine_list[location.name] = max(location.medicines, key=location.medicines.count)
        return location_medicine_list

# Example usage:
web_app = WebApplication()
location1 = Location("Pharmacy A", ["BrandX", "BrandY", "BrandX", "BrandZ"])
location2 = Location("Pharmacy B", ["BrandY", "BrandY", "BrandZ", "BrandZ", "BrandZ"])
web_app.add_location(location1)
web_app.add_location(location2)
print(web_app.generate_location_medicine_list())