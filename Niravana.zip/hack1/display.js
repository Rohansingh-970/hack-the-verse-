const resultsContainer = document.getElementById('results');

// Assuming mostPopularBrandsByLocation is an object with location as key and brand as value
for (const [location, brand] of Object.entries(mostPopularBrandsByLocation)) {
  const locationElement = document.createElement('h2');
  locationElement.textContent = location;

  const brandElement = document.createElement('p');
  brandElement.textContent = `Most popular brand: ${brand}`;

  resultsContainer.appendChild(locationElement);
  resultsContainer.appendChild(brandElement);
}
